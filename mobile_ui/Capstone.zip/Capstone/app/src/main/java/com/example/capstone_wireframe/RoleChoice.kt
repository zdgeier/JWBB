package com.example.capstone_wireframe
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.Navigation
import me.ibrahimsn.particle.ParticleView

/**
 * A simple [Fragment] subclass.
 *
 */
class RoleChoice : Fragment() {
    private lateinit var particleView: ParticleView
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_role_choice, container, false)
        val studentButton: Button = v.findViewById(R.id.RoleChoice_ButtonStudent)
        val professorButton: Button = v.findViewById(R.id.RoleChoice_ButtonProfessor)
        val userName: TextView = v.findViewById(R.id.RoleChoice_UserName)
        val promptText: TextView = v.findViewById(R.id.RoleChoice_Description)
        val userIcon: ImageView = v.findViewById(R.id.RoleChoice_UserIcon)

        studentButton.setOnClickListener {
            Navigation.findNavController(v).navigate(R.id.action_roleChoice_to_studentCheckIn) }
        professorButton.setOnClickListener {
            Navigation.findNavController(v).navigate(R.id.action_roleChoice_to_professorCheckIn) }

        userName.text = getString(R.string.current_user_name)
        promptText.text = getString(R.string.rolechoice_prompt)

        particleView = v.findViewById(R.id.particleView)

        return v;
    }

    override fun onResume() {
        super.onResume()
        particleView.resume()
    }

    override fun onPause() {
        super.onPause()
        particleView.pause()
    }
}
